#pragma once

class BlockParser 
{
protected:
  bool FindCommand(char *&rpchBuffer, int &rszLength);

};